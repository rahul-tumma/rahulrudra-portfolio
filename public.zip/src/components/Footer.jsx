import { motion } from 'framer-motion';
import { FaGithub, FaLinkedin, FaTwitter, FaCode, FaHeart } from 'react-icons/fa';

const Footer = () => {
  const socialLinks = [
    { 
      icon: FaGithub, 
      link: "https://github.com/rahultumma", 
      label: "GitHub",
      color: "hover:text-[#2dba4e]" 
    },
    { 
      icon: FaLinkedin, 
      link: "https://linkedin.com/in/rahultumma", 
      label: "LinkedIn",
      color: "hover:text-[#0077b5]" 
    },
    { 
      icon: FaTwitter, 
      link: "https://twitter.com/rahultumma",
      label: "Twitter",
      color: "hover:text-[#1DA1F2]" 
    },
    { 
      icon: FaCode, 
      link: "https://leetcode.com/rahultumma", 
      label: "LeetCode",
      color: "hover:text-[#ffa116]" 
    }
  ];

  return (
    <footer className="bg-[#0a0a0f] relative overflow-hidden">
      {/* Matrix Code Rain Effect */}
      <div className="absolute inset-0 bg-[url('/matrix.svg')] bg-repeat animate-matrix opacity-5"></div>

      {/* Glowing Border */}
      <div className="h-px bg-gradient-to-r from-transparent via-blue-500 to-transparent w-full"></div>

      <div className="container mx-auto px-4 py-12 relative z-10">
        <div className="max-w-6xl mx-auto">
          {/* Main Footer Content */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            {/* Brand Section */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
                &lt;Rahul Tumma /&gt;
              </h3>
              <p className="text-gray-400 font-mono">
                Building digital experiences with code and creativity
              </p>
            </motion.div>

            {/* Quick Links */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="space-y-4"
            >
              <h4 className="text-lg font-semibold text-white">Quick Links</h4>
              <ul className="space-y-2 font-mono">
                {['Home', 'Projects', 'About', 'Contact'].map((item, index) => (
                  <li key={index}>
                    <a 
                      href={`#${item.toLowerCase()}`}
                      className="text-gray-400 hover:text-blue-400 transition-colors flex items-center gap-2"
                    >
                      <FaCode className="text-xs" />
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </motion.div>

            {/* Contact Info */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="space-y-4"
            >
              <h4 className="text-lg font-semibold text-white">Contact</h4>
              <div className="font-mono space-y-2 text-gray-400">
                <p className="hover:text-blue-400 transition-colors cursor-pointer">
                  contact@yourdomain.com
                </p>
                <p className="hover:text-blue-400 transition-colors cursor-pointer">
                  +1 234 567 890
                </p>
              </div>
            </motion.div>

            {/* Social Links */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="space-y-4"
            >
              <h4 className="text-lg font-semibold text-white">Connect</h4>
              <div className="flex space-x-4">
                {socialLinks.map((social, index) => (
                  <motion.a
                    key={index}
                    href={social.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`text-gray-400 ${social.color} transition-all duration-300`}
                    whileHover={{ scale: 1.2, rotate: 360 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <social.icon size={24} />
                  </motion.a>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Bottom Bar */}
          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="pt-8 mt-8 border-t border-gray-800"
          >
            <div className="flex flex-col md:flex-row justify-between items-center font-mono text-sm text-gray-400">
              <div className="flex items-center space-x-2">
                <span>Made with</span>
                <FaHeart className="text-red-500 animate-pulse" />
                <span>using React & Tailwind</span>
              </div>
              <div className="mt-4 md:mt-0">
                <span className="text-gray-500">&copy; {new Date().getFullYear()} Rahul Tumma. All rights reserved.</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Terminal-style decoration */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-blue-500"></div>
    </footer>
  );
};

export default Footer; 